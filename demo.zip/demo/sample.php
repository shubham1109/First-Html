<html>
<body onLoad="slide">
<div class="container-fluid">
  <p class="containerscroll"></p>
<nav class="navbar navbarj navbar-default navbar-fixed-top navbar-static-top" id="nav-pills">
  <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <ul class="nav nav-pills navbar-responsive">
          <li role="presentation"><a href="#">Home</a></li>
        </ul>  
      </div>
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">     
        <ul class="nav nav-pills">
          <li role="presentation"><a href="#">Profile</a></li>
          <li role="presentation"><a href="#">Messages</a></li>
          <li role="presentation"><a href="#">Contact Us</a></li>
          <li role="presentation"><a href="#">About Us</a></li>
          <div id="searchscroll"></div>
        </ul>
      </div>
</nav>
</div>



<div class="sliders">
  <img id="img" src="demopics/img.jpg">
  <div class="buttons">
    <button class="btn">button</button>
  </div>
</div>
</body>
</html>

<style type="text/css">
.sliders{
  height:80%;
  width: 100%;
  position: relative;
}

#img{
  height: 80%;
  width: 100%;
  position: absolute;
}

.buttons{
  left: 70%;
  top: 30%;
  width: 100px;
  position: absolute;
}
.btn{
  position: absolute;

}
</style>
<script type="text/javascript">
 var imagecount=0;
 var total=2;
 window.setInterval(function slide(){
  var Image= document.getElementById("img");
  imagecount=imagecount+1;
  if(imagecount>total){imagecount=1;}
  if(imagecount<1){imagecount=total;}
  Image.src="demopics/img"+imagecount+".jpg";

 },5000)
</script>
<div class="caption1">
    <h3 class="captions1">“Coding sparks creativity, inspiration and innovation —

all of which are essential in any career.”</br>

Floresa, teacher
</h3>
</div>
<div class="caption2">
<h3 class="captions2">stay happ</h3>
</div>
<div class="caption3">
<h3 class="captions3">2.5 million girls are enrolled to learn on Code Studio</h3>
 


  </div>
















  
<footer>
  <div class="footer">
    
    <div class="footerlinks">
      <img class="footerimg"src="demopics/footer.jpg">

      <ul class="footerlinksul">
        <li><a href="#">Blog</a></li>
        <li><a href="#">      Donate</a></li>
        <li><a href="#">Support</a></li>
        <li><a href="#">About</a></li>
      </ul>
    </div>
  </div>  
 </div>
<footer>

  <div class="col-lg-4 col-md-12 col-xs-12 fixedcontent"style="backgroundcolor:white" >
  <div id="f1_container">
   <div id="f1_card" class="shadow">  
    <div class="front face">
     <img src="demopics/iphone2.jpg">
    </div>
    <div class="back face center">
     <p>This is nice for exposing more information about an image.</p>
     <p>Any content can go here.</p>
    </div>
   </div>
  </div>
 </div> 


 <div class="col-lg-4 col-md-12 col-xs-12 fixedcontent"style="backgroundcolor:white">
  <div id="f1_container">
   <div id="f1_card" class="shadow">  
     <div class="front face">
       <img src="demopics/contentimg.jpg">
     </div>
     <div class="back face center">
      <p>This is nice for exposing more information about an image.</p>
      <p>Any content can go here.</p>
     </div>
   </div> 
  </div> 
 </div>


 <div class="col-lg-4 col-md-12 col-xs-12 fixedcontent"style="backgroundcolor:white">
  <div id="f1_container">
   <div id="f1_card" class="shadow">  
     <div class="front face">
       <img src="demopics/p2.jpg">
     </div>
     <div class="back face center">
       <p>This is nice for exposing more information about an image.</p>
       <p>Any content can go here.</p>
     </div>
   </div> 
  </div> 
 </div>




 @media all and (max-width: 4000px){
#f1_container {
  position: relative;
  margin: 0px auto;
 
  z-index: 1;
 
}
#f1_container {
  perspective: 1000;
}
#f1_card {
  width: 420px;
  height: 235px;
  margin-top: 80px;
  margin-bottom: 80px;
  transform-style: preserve-3d;
  transition: all 0.5s linear;
  box-shadow: -2px 2px 2px #000;
}
#f1_container:hover #f1_card {
  transform: rotateY(180deg);
  box-shadow: -2px 2px 2px #fff;
}
.face {
  position: absolute;
  width: 100%;
  height: 100%;
  backface-visibility: hidden;
}
.front > img{
  width: 420px;
  height: 235px;
}
.face.back {
  display: block;
  transform: rotateY(180deg);
  box-sizing: border-box;
  padding: 10px;
  color:#fff;
  text-align: center;
  background-color: #539286;
}}



 <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone1.jpg" height="294px" width="294px"/>
       </div>
    <!--/.grid-block-->
  </div>
  <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone3.jpg" height="294px" width="294px"/>
       </div>
    <!--/.grid-block-->
  </div>
  <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone4.jpg" height="294px" width="294px"/>
       </div>

    </div>   
     <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone4.jpg" height="294px" width="294px"/>
       </div>
       
    </div>   
























    <div class="newrelease">
    <h3>Product Name</h3>
    <img src="demopics/newrelease1.png">
 </div> 
 <div class="newrelease">
    <h3>Product Name</h3>
    <img src="demopics/newrelease2.png">
 </div> 
 <div class="otherproducts">
    <h3>Other Products</h3>
 </div> 
 
</div>  
<div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone1.jpg" height="294px" width="294px"/>
       </div>
    <!--/.grid-block-->
  </div>
  <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone3.jpg" height="294px" width="294px"/>
       </div>
    <!--/.grid-block-->
  </div>
  <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone4.jpg" height="294px" width="294px"/>
       </div>

    </div>   
     <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12 belowflip">
       <div class="grid-block slide">
          <div class="captionofimg">
            <h3>Caption Title</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p><a href="#" class="learn-more">Learn more</a></p>
          </div>
        <img src="demopics/iphone4.jpg" height="294px" width="294px"/>
       </div>
       
    </div> 








     $(document).ready(function() {
    $('.slide').hover(
    function(){
      $(this).find('.memberinfo').effect({
                  effect: "slide",
                  distance:335,
                  times:1,
                  duration: 500
               });
    },
    function(){
      $(this).find('.memberinfo').slideUp(600);
    }
  );
});

 $(document).ready(function() {
    $('.slide1').hover(
    function(){
      $(this).find('.memberinfo').slideDown(600);
    },
    function(){
      $(this).find('.memberinfo').fadeOut(1000);
    }
  );
});   







<div id="owl-demo">
          
  <div class="item" id="item1">
     <div id="caption1">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder1.jpg" alt="coders">
  </div>
  <div class="item" id="item2">
    <div id="caption2">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder2.jpg" alt="coders">
  </div>
  <div class="item" id="item3">
    <div id="caption3">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder3.jpg" alt="coders">
  </div>
  <div class="item" id="item4">
    <div id="caption4">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder4.jpg" alt="coders">
  </div>
  <div class="item" id="item5">
    <div id="caption5">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder5.jpg" alt="coders">
  </div>
  <div class="item" id="item6">
    <div id="caption6">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder6.jpg" alt="coders">
  </div>
  <div class="item" id="item7">
    <div id="caption7">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder7.jpg" alt="coders">
  </div>
  <div class="item" id="item8">
    <div id="caption8">
      <h3>Caption Here</h3>
      <p>here the detail of the image</p>
    </div>
    <img src="pics/coder8.jpg" alt="coders">
  </div>
 
</div>





 <form id="login-form" method="post" class="form-signin" role="form">
      <h3><span class="glyphicon glyphicon glyphicon-user" aria-hidden="true"></span>User Login</h3>
      <label id="Username" class="label_username" >Username</label></br>
      <input name="username" id="username" type="username" class="form-control signininput"placeholder="Username" size="15"  autofocus required></br> 
      <label id="psw" class="label_psw">Password</label>
      <input name="password" id="password" type="password" class="form-control signinpassword disable" placeholder="Password" size="15" required>
    </form>
    <button class="btn  btn-login buttons signinsubmit" type="submit" data-toggle="modal" data-target="#signinsuccess" onclick="User()" data-dismiss="modal"><strong>Sign In</strong></button>


    <form id="Signup-form" method="post" class="form-signup" role="form">
      <h3>Join The Developer's Network</h3>
      <label id="Username" class="label_username" >Email</label>
      <input name="email" id="email" type="email" class="form-control" placeholder="Email" size="15"  required></br> 
      <label id="psw" class="label_psw">Password</label>
      <input name="fpassword" id="password" type="password" class="form-control  " placeholder="Password" size="15" required></br>
      <label id="psw" class="label_psw">Confirm Password</label>
      <input name="fpassword" id="password" type="password" class="form-control  " placeholder="Confirm Password" size="15" required>
    </form>
    <button class="btn  btn-login buttons signupsubmit" type="submit" data-toggle="modal" data-target="#signinsuccess" onclick="User()" data-dismiss="modal"><strong>Sign Up</strong></button>