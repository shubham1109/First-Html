   $(document).ready(function(e) {
 	$('#navbar').removeClass('fixednavbar');

        $(window).scroll(function () {
            if ($(window).scrollTop() > 30 ) {

                $('#navbar').addClass('fixednavbar');
                $('#navbar').removeClass('navbar'); 

            } else {
                $('#navbar').removeClass('fixednavbar');
                $('#navbar').addClass('navbar');     
            }
        });         

    });


  $(document).ready(function(e) {
  $('#navbarsignup').removeClass('fixednavbar');

        $(window).scroll(function () {
            if ($(window).scrollTop() > 30 ) {

                $('#navbarsignup').addClass('fixednavbar');
                $('#navbarsignup').removeClass('navbarsignup'); 

            } else {
                $('#navbarsignup').removeClass('fixednavbar');
                $('#navbarsignup').addClass('navbarsignup');     
            }
        });         

    });


   $(document).ready(function(e) {
  $('#navbarteam').removeClass('fixednavbar');

        $(window).scroll(function () {
            if ($(window).scrollTop() > 30 ) {

                $('#navbarteam').addClass('fixednavbar');
                $('#navbarteam').removeClass('navbarteam'); 

            } else {
                $('#navbarteam').removeClass('fixednavbar');
                $('#navbarteam').addClass('navbarteam');     
            }
        });         

    });


function passwordStrength(){
  var str=document.getElementById("password1").value;
    var x= str.length;
    if(x<6){
      
      document.getElementById("pswd").className = "pswd";
    }
    else if(x>=6 && x<=8){
    
    document.getElementById("pswd").className = "pswd1";  
    }
    else if(x>=9){
      
      document.getElementById("pswd").className = "pswd2";
    }
    else{
        document.getElementById("pswd").className = "pswd3";
    }
}



 


 $(document).ready(function() { 
    slideShow();
   });
 function slideShow(){
  $("#imgsdiv").fadeIn(1500).delay(7500).fadeOut(1500);
    $("#imgsdiv1").fadeOut(1500).delay(9000).fadeIn(1500).delay(7500).fadeOut(1500);
    $("#imgsdiv2").fadeOut(1500).delay(19500).fadeIn(1500).delay(7500).fadeOut(1500);
    setTimeout(slideShow,31000);
 }
  $(document).ready(function() { 
    slideShowCaption();
   });
 function slideShowCaption(){
    $("#captions1").fadeIn(2500).delay(4500).fadeOut(1500);
    $("#captions2").fadeOut(1500).delay(9000).fadeIn(2500).delay(4500).fadeOut(1500);
     $("#captions3").fadeOut(1500).delay(19500).fadeIn(2500).delay(4500).fadeOut(1500);
   
    
    setTimeout(slideShowCaption,31000);
 }

$(document).ready(function() {
    $('.slide').hover(
    function(){
      $(this).find('.captionofimg').fadeIn(600);
    },
    function(){
      $(this).find('.captionofimg').fadeOut(600);
    }
  );
});





 





  $(document).ready(function(e) {
    $('#headline').removeClass('headlinehide');

       $(window).scroll(function () {
            if ($(window).scrollTop() > 5 ) {
               $('#headline').addClass('headlinehide');
                $('#headline').removeClass('headline'); 
              } else {
                $('#headline').removeClass('headlinehide');
                $('#headline').addClass('headline'); 
    }
        });         

    });

  

 

 $(document).ready(function() {
    $('.navbar-default .navbar-nav > li > a').hover(
    function(){
      $(this).find('.menu').slideDown(600);
    },
    function(){
      $(this).find('.menu').slideUp(1000);
    }
  );
});   



$(function() {
    $("#arrow").on("click", function() {
        $("body").animate({"scrollTop": window.scrollY=650}, 500);
        return false;
    });
}); 


$(document).ready(function() {
        $("#newrelease").click(function() {
            $('#newrelease11').delay(500).fadeIn(500);
             $('#newrelease12').delay(500).fadeIn(500);
        });
    });




 $(document).ready(function() {
            $('#newrelease').click(function() {
               $( "#newrelease" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
            });
         });

   $(document).ready(function() {
        $("#newrelease").click(function() {
            $('#newrelease11').delay(500).fadeIn(500);
             $('#newrelease12').delay(500).fadeIn(500);
        });
    });
    $(document).ready(function() {
            $('#newrelease11').click(function() {
               $( "#newrelease11" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 5,
                  duration: 500
   });
                $( "#newrelease12" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 5,
                  duration: 500
   });
            });
         });
     $(document).ready(function() {
            $('#newrelease12').click(function() {
               $( "#newrelease11" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 5,
                  duration: 500
   });
               $( "#newrelease12" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 5,
                  duration: 500
   });
            });
         });
      $(document).ready(function() {
        $("#newrelease11").click(function() {
            $('#newrelease').fadeIn(1000);
            
        });
    });
       $(document).ready(function() {
        $("#newrelease12").click(function() {
            $('#newrelease').fadeIn(1000);
            
        });
    });

  $(document).ready(function() {
        $("#viewdetailbtn").click(function() {
            $( "#newrelease" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
        });
    });
$(document).ready(function() {
        $("#viewdetailbtn").click(function() {
            $('#about').fadeIn(1000);
            $("#viewdetailbtn").hide();
        });
    });
 $(document).ready(function() {
        $("#backimage").click(function() {
            $( "#about" ).fadeOut(500);
        });
    });
 $(document).ready(function() {
        $("#backimage").click(function() {
            $('#newrelease').fadeIn(1000);
            $("#viewdetailbtn").show();
        });
    });




 $(document).ready(function() {
        $("#newrelease1").click(function() {
            $('#newrelease21').delay(500).fadeIn(500);
             $('#newrelease22').delay(500).fadeIn(500);
        });
    });




 $(document).ready(function() {
            $('#newrelease1').click(function() {
               $( "#newrelease1" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
            });
         });

   $(document).ready(function() {
        $("#newrelease1").click(function() {
            $('#newrelease21').delay(500).fadeIn(500);
             $('#newrelease22').delay(500).fadeIn(500);
        });
    });
    $(document).ready(function() {
            $('#newrelease21').click(function() {
               $( "#newrelease21" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
                $( "#newrelease22" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
            });
         });
     $(document).ready(function() {
            $('#newrelease22').click(function() {
               $( "#newrelease21" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
               $( "#newrelease22" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
            });
         });
      $(document).ready(function() {
        $("#newrelease21").click(function() {
            $('#newrelease1').fadeIn(1000);
            
        });
    });
       $(document).ready(function() {
        $("#newrelease22").click(function() {
            $('#newrelease1').fadeIn(1000);
            
        });
    });

  $(document).ready(function() {
        $("#viewdetailbtn1").click(function() {
            $( "#newrelease1" ).effect({
                  effect: "explode",
                  easing: "easeInExpo",
                  pieces: 50,
                  duration: 500
   });
        });
    });
$(document).ready(function() {
        $("#viewdetailbtn1").click(function() {
            $('#about1').fadeIn(1000);
            $("#viewdetailbtn1").hide();
        });
    });
 $(document).ready(function() {
        $("#backimage1").click(function() {
            $( "#about1" ).fadeOut(500);
        });
    });
 $(document).ready(function() {
        $("#backimage1").click(function() {
            $('#newrelease1').fadeIn(1000);
            $("#viewdetailbtn1").show();
        });
    });


$(document).ready(function() {
    $('#searchbutton').hover(
    function(){
      $('#search').show({left: '250px'});
    }
  );
});

$(document).ready(function() {
    $('#search').hover(
    function(){
      $('#search').show();
    },
    function(){
      $('#search').hide({left: '250px'});
    }
  );
});
