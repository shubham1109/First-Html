 
 
   









  $(document).ready(function() {
    $('#slide0').hover(
    function(){
       $('#memberinfo0').show( {"top": "+=294px"}, 500, "linear" );
      
    },
    function(){
      $('#memberinfo0').hide( {"top": "+=294px"}, 500, "linear" );
    
    }
  );
});

 $(document).ready(function() {
    $('#slide1').hover(
    function(){
      $('#memberinfo1').show( {"top": "+=294px"}, 500, "linear" );
    },
    function(){
      $('#memberinfo1').hide( {"top": "+=294px"}, 500, "linear" );
    }
  );
});

 $(document).ready(function() {
    $('#slide2').hover(
    function(){
       $('#memberinfo2').show( {"top": "+=294px"}, 500, "linear" );
    },
    function(){
      $('#memberinfo2').hide( {"top": "+=294px"}, 500, "linear" );
    }
  );
});

 $(document).ready(function() {
    $('#slide3').hover(
    function(){
       $('#memberinfo3').show( {"top": "+=294px"}, 500, "linear" );
    },
    function(){
       $('#memberinfo3').hide( {"top": "+=294px"}, 500, "linear" );
    }
  );
});

 $(document).ready(function() {
    $('#slide4').hover(
    function(){
      $('#memberinfo4').show( {"top": "+=294px"}, 500, "linear" ); 
    },
    function(){
      $('#memberinfo4').hide( {"top": "+=294px"}, 500, "linear" ); 
    }
  );
});

 $(document).ready(function() {
    $('#slide5').hover(
    function(){
       $('#memberinfo5').show( {"top": "+=294px"}, 500, "linear" );
    },
    function(){
      $('#memberinfo5').hide( {"top": "+=294px"}, 500, "linear" );
    }
  );
});

 $(document).ready(function() {
    $('#slide6').hover(
    function(){
      $('#memberinfo6').show( {"top": "+=294px"}, 500, "linear" );
    },
    function(){
      $('#memberinfo6').hide( {"top": "+=294px"}, 500, "linear" );
    }
  );
});

 $(document).ready(function() {
    $('#slide7').hover(
    function(){
      $('#memberinfo7').show( {"top": "+=294px"}, 500, "linear" );
    },
    function(){
      $('#memberinfo7').hide( {"top": "+=294px"}, 500, "linear" );
    }
  );
});  



 

 $(document).ready(function() {
  
  $('#drop').click(function() {
    $('#work').animate({
        height: '750'
    });
    $('#Up').show();
    $('#drop').hide();
  });
});
$(document).ready(function() {
  $('#Up').click(function() {
    $('#work').animate({
        height: '70px'
    });
    
    $('#drop').show();
    $('#Up').hide();
  });
});


 